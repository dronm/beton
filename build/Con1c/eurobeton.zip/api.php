<?php
	set_time_limit(300);
	
	session_start();
	
	require_once('http_header.php');
	require_once('functions.php');
	
	header('Content-Type: application/json; charset=utf-8');
	//йф
	
	define('SECRET', 'd79bcbd8-d7e0-4c84-b73b-7052ae95f81f');
	
	define('ER_FORBIDDEN', 'Не авторизован.');
	
	define('COM_OBJ_NAME', 'v8Server.Connection');
	
	/**
	 * Command list
	 *	get_client_dog_oborot() http://localhost:8181/api.php?cmd=get_client_dog_oborot&date_from=2022-10-01T00:00:00&key=d79bcbd8-d7e0-4c84-b73b-7052ae95f81f
	 *
	 *	get_catalog_by_attr() http://localhost:8181/api.php?cmd=get_catalog_by_attr&catalog=clients&search=Кофеин&key=d79bcbd8-d7e0-4c84-b73b-7052ae95f81f
	 */
	$result = 0;
	$descr = '""';
	$models = '';
	try{
		if(!isset($_REQUEST['cmd'])
			||!isset($_REQUEST['key'])
			||$_REQUEST['key']!=SECRET
		){
			set_headers_status(401);
			throw new Exception('Unauthorized access');
		}
				
		if($_REQUEST['cmd'] == 'get_client_dog_oborot'){
			//if(!isset($_REQUEST['date_from'])){
			//	throw new Exception('Parameter date_from not found');
			//}
			//$par_date = date("Y,m,d,23,59,59", strtotime($_REQUEST['date_from']));

			$v8 = new COM(COM_OBJ_NAME);
			$models = get_client_dog_oborot($v8);
		
		}else if($_REQUEST['cmd'] == 'get_catalog_by_attr'){
			if(!isset($_REQUEST['catalog']) || !isset($_REQUEST['search'])){
				throw new Exception('Parameter not found');
			}
			$v8 = new COM(COM_OBJ_NAME);
			if($_REQUEST['catalog'] == 'clients'){
				$models = get_client_by_attr($v8,  iconv('UTF-8', 'Windows-1251', $_REQUEST['search']));
			}
		}else{
			throw new Exception('command not found');				
		}
	}catch (Exception $e){
		//error
		$result = 1;
		$msg = $e->getMessage();
		$current_encoding = mb_detect_encoding($msg, ['UTF-8', 'Windows-1251']);
		if($current_encoding == 'Windows-1251'){
			$msg = iconv('Windows-1251', 'UTF-8',$msg);
		}
		$descr = json_encode($msg, JSON_UNESCAPED_UNICODE);		
	}
	if(strlen($models)){
		$models = sprintf(',%s', $models);
	}
	$resp = sprintf('{"models": {"ModelServResponse": {"rows": [{"result": %d, "descr": %s}]}%s}}', $result, $descr, $models);	
	echo $resp;
?>